<template>
  <div class="spinner-wrapper">
    <div class="loadingio-spinner-dual-ring-pv9b1oqrhi">
    <div class="ldio-jw37a2op4sd">
      <div></div>
      <div><div></div></div>
    </div>
  </div>
  </div>
</template>

<style>
@keyframes ldio-jw37a2op4sd {
  0% {
    transform: rotate(0);
  }
  100% {
    transform: rotate(360deg);
  }
}
.ldio-jw37a2op4sd div {
  box-sizing: border-box !important;
}
.ldio-jw37a2op4sd > div {
  position: absolute;
  width: 71px;
  height: 71px;
  top: 14.5px;
  left: 14.5px;
  border-radius: 50%;
  border: 5px solid #000;
  border-color: #ac5b39 transparent #ac5b39 transparent;
  animation: ldio-jw37a2op4sd 1s linear infinite;
}
.ldio-jw37a2op4sd > div:nth-child(2) {
  border-color: transparent;
}
.ldio-jw37a2op4sd > div:nth-child(2) div {
  position: absolute;
  width: 100%;
  height: 100%;
  transform: rotate(45deg);
}
.ldio-jw37a2op4sd > div:nth-child(2) div:before,
.ldio-jw37a2op4sd > div:nth-child(2) div:after {
  content: "";
  display: block;
  position: absolute;
  width: 5px;
  height: 5px;
  top: -5px;
  left: 28px;
  background: #ac5b39;
  border-radius: 50%;
  box-shadow: 0 66px 0 0 #ac5b39;
}
.ldio-jw37a2op4sd > div:nth-child(2) div:after {
  left: -5px;
  top: 28px;
  box-shadow: 66px 0 0 0 #ac5b39;
}
.loadingio-spinner-dual-ring-pv9b1oqrhi {
  width: 70px;
  height: 70px;
  display: inline-block;
  overflow: hidden;
  background: none;
}
.ldio-jw37a2op4sd {
  width: 100%;
  height: 100%;
  position: relative;
  transform: translateZ(0) scale(0.7);
  backface-visibility: hidden;
  transform-origin: 0 0; 
}
.ldio-jw37a2op4sd div {
  box-sizing: content-box;
}
.spinner-wrapper {
  width: 100%;
  display: flex;
  justify-content: center;
}
</style>